// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDQvQkyuclLriMrY47f--TIHDmrMRYmrJM",
  authDomain: "whatsappdemo-b1bae.firebaseapp.com",
  projectId: "whatsappdemo-b1bae",
  storageBucket: "whatsappdemo-b1bae.appspot.com",
  messagingSenderId: "146699262436",
  appId: "1:146699262436:web:81ca430cfae50c25d0cff1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);