export const DATABASE_CONNECTION = 'mongodb+srv://admin:1234@cluster0.rxt52.mongodb.net/myFirstDatabase?retryWrites=true&w=majority';
export const POST_MODEL = 'POST_MODEL';
export const USER_MODEL = 'USER_MODEL';
export const COMMENT_MODEL = 'COMMENT_MODEL';